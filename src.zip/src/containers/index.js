export {default as Header} from "./header/Header";
export {default as HowToBuy} from "./howToBuy/HowToBuy";
export {default as LatestNews} from "./latestNews/LatestNews";
export {default as FirstTime} from "./firstTime/FirstTime";
export {default as Faq} from "./faq/Faq";
export {default as Footer} from "./footer/Footer";